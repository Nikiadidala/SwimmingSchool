
import hjss_package.Booking;
import hjss_package.Coach;
import hjss_package.Learner;
import hjss_package.Lesson;
import hjss_package.Rating;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import static org.junit.Assert.*;
import org.junit.Test;

public class TestingClass {
    
    
    @Test
    public void testTimetable() {
        System.out.println("\n-------------------------------");
        System.out.println("\n\nTest Description : Test Case To check whether the learner is able to view the timetable.");
        List<Lesson> lessons = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        System.out.println("\n");
        System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", "Lesson Code","Name", "Date", "Day", "Slot", 
                "Grade Level","Available Seats", "Taught By");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        Set<String> uniqueRows = new HashSet<>();

        for (int i = 0; i < lessons.size(); i++) {
            String key = lessons.get(i).getLessonCode() + lessons.get(i).getGradeLevel() + lessons.get(i).getName() +
                    lessons.get(i).getDay() + lessons.get(i).getSlot() + lessons.get(i).getDate();
            if (uniqueRows.add(key)) {
                String coach = "";
                for (int j = 0; j < coachList.size(); j++) {
                    if (coachList.get(j).getUserId() == lessons.get(i).getTaughtBy()) {
                        coach = coachList.get(j).getName();
                    }
                }
                String code = lessons.get(i).getLessonCode();
                String grade = String.valueOf(lessons.get(i).getGradeLevel());
                String day = lessons.get(i).getDay();
                String slot = lessons.get(i).getSlot();
                String seats = String.valueOf(lessons.get(i).getAvailableSeats());
                String date = lessons.get(i).getDate();
                String name = lessons.get(i).getName();
                System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", code, name, date, day, slot,
                        grade, seats, coach);
            }
        }
        assertTrue(!lessons.isEmpty());
        System.out.println("\nResult : Test Passed");
    }
    
    
    
    
    @Test
    public void testDayFilterOfTimetable() {
       System.out.println("\n-------------------------------");

       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to filter the timetable by given day.");
       
        List<Lesson> lessons = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        
        String filter_day = "Monday";
        
        System.out.println("\nGiven Day : "+filter_day);
        
        System.out.println("\n");
        System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", "Lesson Code","Name", "Date", "Day", "Slot", 
                "Grade Level","Available Seats", "Taught By");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        
        Set<String> uniqueRows = new HashSet<>();

        for (int i = 0; i < lessons.size(); i++) {
            String key = lessons.get(i).getLessonCode() + lessons.get(i).getGradeLevel() + lessons.get(i).getName() +
                    lessons.get(i).getDay() + lessons.get(i).getSlot() + lessons.get(i).getDate();

            if (filter_day.equalsIgnoreCase(lessons.get(i).getDay())) {
                if (uniqueRows.add(key)) {
                    String coach = "";
                    for (int j = 0; j < coachList.size(); j++) {
                        if (coachList.get(j).getUserId() == lessons.get(i).getTaughtBy()) {
                            coach = coachList.get(j).getName();
                        }
                    }

                    String code = lessons.get(i).getLessonCode();
                    String grade = String.valueOf(lessons.get(i).getGradeLevel());
                    String day = lessons.get(i).getDay();
                    String slot = lessons.get(i).getSlot();
                    String seats = String.valueOf(lessons.get(i).getAvailableSeats());
                    String date = lessons.get(i).getDate();
                    String name = lessons.get(i).getName();

                    System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", code, name, date, day, slot,
                            grade, seats, coach);
                }
            }
        }
        
        
        assertTrue(!lessons.isEmpty());
        System.out.println("\nResult : Test Passed");
    }
    
    
    
    
    @Test
    public void testGradeFilterOfTimetable() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to filter the timetable by given grade.");
        List<Lesson> lessons = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        int filter_grade = 2;
        System.out.println("\nGiven Grade : "+filter_grade);
        System.out.println("\n");
        System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", "Lesson Code","Name", "Date", "Day", "Slot", 
                "Grade Level","Available Seats", "Taught By");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        Set<String> uniqueRows = new HashSet<>();
        for (int i = 0; i < lessons.size(); i++) {
            String key = lessons.get(i).getLessonCode() + lessons.get(i).getGradeLevel() + lessons.get(i).getName() +
                    lessons.get(i).getDay() + lessons.get(i).getSlot() + lessons.get(i).getDate();

            if (filter_grade == lessons.get(i).getGradeLevel()) {
                if (uniqueRows.add(key)) {
                    String coach = "";
                    for (int j = 0; j < coachList.size(); j++) {
                        if (coachList.get(j).getUserId() == lessons.get(i).getTaughtBy()) {
                            coach = coachList.get(j).getName();
                        }
                    }
                    String code = lessons.get(i).getLessonCode();
                    String grade = String.valueOf(lessons.get(i).getGradeLevel());
                    String day = lessons.get(i).getDay();
                    String slot = lessons.get(i).getSlot();
                    String seats = String.valueOf(lessons.get(i).getAvailableSeats());
                    String date = lessons.get(i).getDate();
                    String name = lessons.get(i).getName();

                    System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", code, name, date, day, slot,
                            grade, seats, coach);
                }
            }
        }
        
        
        assertTrue(!lessons.isEmpty());
        System.out.println("\nResult : Test Passed");
    }
    
    
    
    @Test
    public void testCoachFilterOfTimetable() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to filter the timetable by given coach.");
        List<Lesson> lessons = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        String filter_coach = "William";
        System.out.println("\nGiven Coach : "+filter_coach);
        System.out.println("\n");
        System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", "Lesson Code","Name", "Date", "Day", "Slot", 
                "Grade Level","Available Seats", "Taught By");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
        
        int coachId  = 0;
        for(int i=0; i<coachList.size(); i++){
            if(coachList.get(i).getName().equalsIgnoreCase(filter_coach)){
                coachId = coachList.get(i).getUserId();
            }
        }
        Set<String> uniqueRows = new HashSet<>();
        for (int i = 0; i < lessons.size(); i++) {
            String key = lessons.get(i).getLessonCode() + lessons.get(i).getGradeLevel() + lessons.get(i).getName() +
                    lessons.get(i).getDay() + lessons.get(i).getSlot() + lessons.get(i).getDate();

            if (lessons.get(i).getTaughtBy() == coachId) {
                if (uniqueRows.add(key)) {
                    String coach = "";
                    for (int j = 0; j < coachList.size(); j++) {
                        if (coachList.get(j).getUserId() == lessons.get(i).getTaughtBy()) {
                            coach = coachList.get(j).getName();
                        }
                    }
                    String code = lessons.get(i).getLessonCode();
                    String grade = String.valueOf(lessons.get(i).getGradeLevel());
                    String day = lessons.get(i).getDay();
                    String slot = lessons.get(i).getSlot();
                    String seats = String.valueOf(lessons.get(i).getAvailableSeats());
                    String date = lessons.get(i).getDate();
                    String name = lessons.get(i).getName();
                    System.out.printf("%-13s %-30s %-15s %-15s %-15s %-13s %-16s %-30s %n", code, name, date, day, slot,
                            grade, seats, coach);
                }
            }
        }
        
        assertTrue(!lessons.isEmpty());
        System.out.println("\nResult : Test Passed");
    }
    
    
    
    @Test
    public void testBookClass() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to book a class.");
               
        bookLessons();
       
        List<Booking> bookingList = Booking.returnBookings();
        
        System.out.println("\nOutput : Lesson Booked Successfully");
        
        assertTrue(!bookingList.isEmpty());
        System.out.println("\nResult : Test Passed");
    }
    
    @Test
    public void testChangeBooking() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to change a booking and the lesson "
               + "which was booked earlier, the seat will be increased for that lesson.");
        String bookingNo = "HJJS_No_96584";
        String newLessonCode = "lesson024";
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                String lessonName = bookingList.get(i).getLessonCode();
                //Increase Seats in previous selected lesson - when changed lesson
                for(int j=0; j<lessonList.size(); j++){
                    if(lessonList.get(j).getLessonCode().equalsIgnoreCase(lessonName)){
                        int existingSeats = lessonList.get(j).getAvailableSeats();                                
                        lessonList.get(j).setAvailableSeats(existingSeats+1);
                    }
                }
                bookingList.get(i).setLessonCode(newLessonCode);
                bookingList.get(i).setStatus(Booking.CHANGED);
            }
        }
        System.out.println("\nOutput : Changed Successfully");
        // Validate Changed Status
        boolean isChanged = false;
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                String status = bookingList.get(i).getStatus();
                if(status.equalsIgnoreCase(Booking.CHANGED)){
                    isChanged = true;
                }
            }
        }
        assertTrue(isChanged);
        System.out.println("\nResult : Test Passed");
    }
   
    
    @Test
    public void testBookClassWithSameOrHigherGradeLevel() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is allowed to book a lesson \n"
               + "having the same grade level as their current level or just one more level higher than their current level .");
       
       int userId = 8;
       int selectedGradeOfLesson = 5;
       
       List<Learner> learnerList = Learner.returnLearners();
        int grade = 0;

        for (Learner learner : learnerList) {
            if (learner.getUserId() == userId) {
                grade = learner.getGradeLevel();
            }
        }
        
       if(selectedGradeOfLesson > (grade+1)){
           System.out.println("\nOutput : Selected Grade Level is higher than your current grade level!");
        }else if(selectedGradeOfLesson < grade){
           System.out.println("\nOutput : Selected Grade Level is lower than your current grade level!");
        }
        System.out.println("\nResult : Test Passed");
    }
    
     
     
    @Test
    public void testCancelBooking() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to cancel a booking and the lesson which is cancelled , the seat will be increased  for that lesson.");
        String bookingNo = "HJJS_No_05856";
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();

        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){

                //Increase Seats when cancelled lesson
                for(int j=0; j<lessonList.size(); j++){
                    if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                        lessonList.get(j).setAvailableSeats(lessonList.get(j).getAvailableSeats()+1);
                    }
                }
                bookingList.get(i).setStatus(Booking.CANCELLED);
            }
        }
        System.out.println("\nOutput : Cancelled Successfully");
        // Validate Cancelled Status
        boolean isCancelled = false;
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                String status = bookingList.get(i).getStatus();
                if(status.equalsIgnoreCase(Booking.CANCELLED)){
                    isCancelled = true;
                }
            }
        }
        assertTrue(isCancelled);
        System.out.println("\nResult : Test Passed");
    }
    
    
 
    /**
     * Book Lessons
     */
    private static void bookLessons(){
        Booking obj = new Booking("HJJS_No_78452","lesson041",8,Booking.BOOKED);
        Booking obj1 = new Booking("HJJS_No_96584","lesson012",19,Booking.BOOKED);
        Booking obj2 = new Booking("HJJS_No_05856","lesson006",16,Booking.BOOKED);
        Booking obj3 = new Booking("HJJS_No_58743","lesson018",12,Booking.BOOKED);
        Booking.bookingList.add(obj);
        Booking.bookingList.add(obj1);
        Booking.bookingList.add(obj2);
        Booking.bookingList.add(obj3);
    }
    
    
     
    @Test
    public void testViewBooking() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the admin is able to view all bookings.");
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        List<Learner> learnerList = Learner.returnLearners();
        System.out.println("\n");
        System.out.printf("%-15s %-20s %-17s %-25s %-15s %-15s %-15s %-15s %-15s %-20s %n", "Booking No.","Username", "User Contact", "Name", "Date", 
                "Day","Slot", "Grade Level","Status", "Taught By");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println();
         for(int i=0; i<bookingList.size(); i++){
            String slot = "";
            String date = "";
            String day = "";
            String grade = "";
            String name = "";
            String coach = "";
            String username = "";
            String user_contact = "";
            
             // get Lesson Deatils
                for(int j=0; j<lessonList.size(); j++){
                    if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                        slot = lessonList.get(j).getSlot();
                        date = lessonList.get(j).getDate();
                        day = lessonList.get(j).getDay();
                        grade = String.valueOf(lessonList.get(j).getGradeLevel());
                        name = lessonList.get(j).getName();

                        for(int k=0; k<coachList.size(); k++){
                            if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                                coach = coachList.get(k).getName();
                            }
                        }
                    }
                }
                //Get user detail
                for(int x=0; x<learnerList.size(); x++){
                    if(learnerList.get(x).getUserId() == bookingList.get(i).getUserId()){
                        username = learnerList.get(x).getName();
                        user_contact = learnerList.get(x).getContact();
                    }
                }

                String bookingNo = bookingList.get(i).getBookingNo();
                String status = bookingList.get(i).getStatus();

                System.out.printf("%-15s %-20s %-17s %-25s %-15s %-15s %-15s %-15s %-15s %-20s %n", bookingNo,username, user_contact, name, date, 
                day,slot, grade,status,coach);
         }
       
        System.out.println("\nResult : Test Passed");
    }
    
    
      
    @Test
    public void testAttendLesson() {
       System.out.println("\n-------------------------------");
       System.out.println("\n\nTest Description : Test Case To check whether the learner is able to attend class.After the learner has attended the lesson with one more level higher, their current grade level is updated");
        String bookingNo = "HJJS_No_78452";
        int userId = 0;
        int targerGrade = 4;
         //Get coach id
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        List<Learner> leanerList = Learner.returnLearners();
        int coach = 0;
        int attendedLessonGrade = 0;
        for(int i=0; i<bookingList.size(); i++){     
           if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
              userId = bookingList.get(i).getUserId();
               // get Lesson Details
               for(int j=0; j<lessonList.size(); j++){
                   if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                       for(int k=0; k<coachList.size(); k++){
                           if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                               coach = coachList.get(k).getUserId();
                           }
                       }
                       attendedLessonGrade = lessonList.get(j).getGradeLevel();

                       //Increase Seats when attended lesson
                       lessonList.get(j).setAvailableSeats(lessonList.get(j).getAvailableSeats()+1);
                   }
               }
               //Update status of booking
               bookingList.get(i).setStatus(Booking.ATTENDED);
           }
        }
        
        Rating obj = new Rating(bookingNo,4,"Good",userId,coach);
        Rating.ratingList.add(obj);
        
         
        // Increase Grade Level of Learner after attending lesson of higher level
        for(int i=0; i<leanerList.size(); i++){     
            if(leanerList.get(i).getUserId() == userId){
                int currentGrade = Learner.getCurrentGradeLevel();
                if(attendedLessonGrade > currentGrade){
                    leanerList.get(i).setGradeLevel((leanerList.get(i).getGradeLevel())+1);
                }
                break;
            }
        }
        
        System.out.println("\nOutput : Attended Successfully");
        
        // Validate Attended Status
        boolean isAttended = false;
        
        for(int i=0; i<bookingList.size(); i++){
            if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                String status = bookingList.get(i).getStatus();
                if(status.equalsIgnoreCase(Booking.ATTENDED)){
                    isAttended = true;
                }
            }
        }
        // Validate Grade level Updated or not
        boolean isUpdatedGrade = false;
        
        for(int i=0; i<leanerList.size(); i++){     
            if(leanerList.get(i).getGradeLevel() == targerGrade){
                isUpdatedGrade = true;
            }
        }
        assertTrue(isAttended);
        assertTrue(isUpdatedGrade);
        System.out.println("\nResult : Test Passed");
    }
    

}
