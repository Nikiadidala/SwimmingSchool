
package hjss_package;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;


public class CoachReport extends Report{
    
    /**
     * Export Coach's Average Rating report
     */
    @Override
    public void exportReport(){
               
        // Export report data to a CSV file using BufferedWriter
        HashMap<String, Double> averageRatings = Rating.calculateAverageRating();
        String filename = "CoachAverageRatingReport.csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("Coach,Average Rating\n");
            for (String coachName : averageRatings.keySet()) {
                writer.write(coachName + "," + averageRatings.get(coachName) + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
