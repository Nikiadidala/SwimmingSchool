
package hjss_package;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;


public class ViewBookingJFrame extends javax.swing.JFrame {

    
    public ViewBookingJFrame() {
        initComponents();      
        
        DefaultTableModel model = (DefaultTableModel) listing.getModel();
        listing.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listing.setDefaultEditor(Object.class, null);
        
        //Get User Role
        String role = User.getUserRole();
        if(role.equalsIgnoreCase(User.LEARNER)){
            changeBooking.setVisible(true);
            cancelBooking.setVisible(true);
            exportReports.setVisible(false);
            attendLesson.setVisible(true);
            learners.setVisible(false);
        }else{
            changeBooking.setVisible(false);
            cancelBooking.setVisible(false);
            exportReports.setVisible(true);
            attendLesson.setVisible(false);
            learners.setVisible(true);
        }
        Booking.viewUserBookings(model,role);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        booking = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        timetable = new javax.swing.JLabel();
        logout = new javax.swing.JLabel();
        rating = new javax.swing.JLabel();
        learners = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listing = new javax.swing.JTable();
        exportReports = new javax.swing.JButton();
        changeBooking = new javax.swing.JButton();
        cancelBooking = new javax.swing.JButton();
        attendLesson = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        booking.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        booking.setForeground(new java.awt.Color(0, 51, 102));
        booking.setText("Bookings");
        booking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookingMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("HJSS");

        timetable.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        timetable.setForeground(new java.awt.Color(0, 51, 102));
        timetable.setText("Timetable");
        timetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                timetableMouseClicked(evt);
            }
        });

        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 51, 102));
        logout.setText("Logout");
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });

        rating.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        rating.setForeground(new java.awt.Color(0, 51, 102));
        rating.setText("Ratings");
        rating.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ratingMouseClicked(evt);
            }
        });

        learners.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        learners.setForeground(new java.awt.Color(0, 51, 102));
        learners.setText("Learners");
        learners.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                learnersMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(learners, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timetable, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rating, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(booking, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel4)
                .addGap(33, 33, 33)
                .addComponent(learners)
                .addGap(31, 31, 31)
                .addComponent(timetable)
                .addGap(33, 33, 33)
                .addComponent(booking)
                .addGap(39, 39, 39)
                .addComponent(rating)
                .addGap(36, 36, 36)
                .addComponent(logout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Bookings");

        listing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BookingNo", "User Name", "User Contact", "Lesson Name", "Date", "Day", "Slot", "Grade Level", "Status", "Taught By"
            }
        ));
        jScrollPane1.setViewportView(listing);

        exportReports.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exportReports.setForeground(new java.awt.Color(0, 0, 153));
        exportReports.setText("Export Reports");
        exportReports.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exportReportsMouseClicked(evt);
            }
        });

        changeBooking.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        changeBooking.setForeground(new java.awt.Color(0, 0, 153));
        changeBooking.setText("Change");
        changeBooking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                changeBookingMouseClicked(evt);
            }
        });

        cancelBooking.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cancelBooking.setForeground(new java.awt.Color(0, 0, 153));
        cancelBooking.setText("Cancel");
        cancelBooking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelBookingMouseClicked(evt);
            }
        });

        attendLesson.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        attendLesson.setForeground(new java.awt.Color(0, 0, 153));
        attendLesson.setText("Attend");
        attendLesson.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                attendLessonMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(503, 503, 503)
                                .addComponent(exportReports, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 861, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(25, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(changeBooking, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(cancelBooking, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(attendLesson, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(194, 194, 194))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(exportReports, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelBooking, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(changeBooking, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(attendLesson, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void timetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_timetableMouseClicked
        ViewTimetableJFrame frame = new ViewTimetableJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_timetableMouseClicked

    private void bookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookingMouseClicked
        ViewBookingJFrame frame = new ViewBookingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_bookingMouseClicked

    private void ratingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ratingMouseClicked
        ViewRatingJFrame frame = new ViewRatingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ratingMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
       
        List<Admin> adminList = Admin.returnAdmin();       
        List<Learner> learnerList = Learner.returnLearners();

        for (Learner learner : learnerList) {
            if (learner.getIsLoggedIn() == 1) {
                learner.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
        for (Admin admin : adminList) {
            if (admin.getIsLoggedIn() == 1) {
                admin.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
    }//GEN-LAST:event_logoutMouseClicked

    private void changeBookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_changeBookingMouseClicked
        
        int record = listing.getSelectedRow();

        //If no row selected 
        if(record < 0){
            JOptionPane.showMessageDialog(null, "Select Lesson to Change Class");
            return;
        }

        //If row selected 
        if (record >= 0) {
            String bookingNo = String.valueOf(listing.getValueAt(record,0));
            List<Booking> bookingList = Booking.returnBookings();
                
            for(int i=0; i<bookingList.size(); i++){
                if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.CANCELLED)){
                        JOptionPane.showMessageDialog(null, "Already Cancelled!");
                        return;
                    }
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.ATTENDED)){
                        JOptionPane.showMessageDialog(null, "Already Attended!");
                        return;
                    }
                }
            }
            
            Booking.IS_CHANGING_BOOKING = 1;
            Booking.CHANGING_BOOKING_NO = bookingNo;
            ViewTimetableJFrame frame = new ViewTimetableJFrame();
            frame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_changeBookingMouseClicked

    private void cancelBookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelBookingMouseClicked
       int record = listing.getSelectedRow();

        //If no row selected 
        if(record < 0){
            JOptionPane.showMessageDialog(null, "Select Lesson to Cancel");
            return;
        }

        //If row selected 
        if (record >= 0) {
            String bookingNo = String.valueOf(listing.getValueAt(record,0));
            List<Booking> bookingList = Booking.returnBookings();
            List<Lesson> lessonList = Lesson.returnLessons();
                
            for(int i=0; i<bookingList.size(); i++){
                if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                    
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.CANCELLED)){
                        JOptionPane.showMessageDialog(null, "Already Cancelled!");
                        return;
                    }
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.ATTENDED)){
                        JOptionPane.showMessageDialog(null, "Already Attended!");
                        return;
                    }
                    
                    //Increase Seats when cancelled lesson
                    for(int j=0; j<lessonList.size(); j++){
                        if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                            lessonList.get(j).setAvailableSeats(lessonList.get(j).getAvailableSeats()+1);
                        }
                    }
                    JOptionPane.showMessageDialog(null, "Cancelled Successfully!");
                    bookingList.get(i).setStatus(Booking.CANCELLED);
                }
            }
            
            
            ViewBookingJFrame frame = new ViewBookingJFrame();
            frame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_cancelBookingMouseClicked

    private void exportReportsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exportReportsMouseClicked
         ReportFactory factory = new ReportFactory();

        // Create and call exportReport for CoachReport
        Report coachReport = factory.createReport("Coach");
        coachReport.exportReport();

        // Create and call exportReport for LearnerReport
        Report learnerReport = factory.createReport("Learner");
        learnerReport.exportReport();
        
        JOptionPane.showMessageDialog(null, "CSV files are Exported Successfully in Project Folder!");
    }//GEN-LAST:event_exportReportsMouseClicked

    private void learnersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_learnersMouseClicked
        ViewLearnerJFrame frame = new ViewLearnerJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_learnersMouseClicked

    private void attendLessonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_attendLessonMouseClicked
       int record = listing.getSelectedRow();

        //If no row selected 
        if(record < 0){
            JOptionPane.showMessageDialog(null, "Select Lesson to Attend");
            return;
        }

        //If row selected 
        if (record >= 0) {
            String bookingNo = String.valueOf(listing.getValueAt(record,0));
                        
            List<Booking> bookingList = Booking.returnBookings();
                
            for(int i=0; i<bookingList.size(); i++){
                if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                    
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.CANCELLED)){
                        JOptionPane.showMessageDialog(null, "Already Cancelled!");
                        return;
                    }
                    if(bookingList.get(i).getStatus().equalsIgnoreCase(Booking.ATTENDED)){
                        JOptionPane.showMessageDialog(null, "Already Attended!");
                        return;
                    }
                    
                    JOptionPane.showMessageDialog(null, "Give Rating to Coach to Attend Lesson!");
                }
            }
            
            Rating.ATTENDING_BOOKING_NO = bookingNo;
            
            ViewRatingJFrame frame = new ViewRatingJFrame();
            frame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_attendLessonMouseClicked

    
  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewBookingJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton attendLesson;
    private javax.swing.JLabel booking;
    private javax.swing.JButton cancelBooking;
    private javax.swing.JButton changeBooking;
    private javax.swing.JButton exportReports;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel learners;
    private javax.swing.JTable listing;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel rating;
    private javax.swing.JLabel timetable;
    // End of variables declaration//GEN-END:variables
}
