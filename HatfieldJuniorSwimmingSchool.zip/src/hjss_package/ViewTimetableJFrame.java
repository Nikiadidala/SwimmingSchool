
package hjss_package;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;



public class ViewTimetableJFrame extends javax.swing.JFrame {

    
    public ViewTimetableJFrame() {
        initComponents();   
        
        DefaultTableModel model = (DefaultTableModel) listing.getModel();
        listing.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listing.setDefaultEditor(Object.class, null);
        
        Lesson.loadTimetable(model,0,"","");
        
        // Insert coach names to combo box
        Set<String> uniqueNames = new HashSet<>();
        coachCombo.removeAllItems();
        coachCombo.addItem("Select Coach");
        List<Coach> coach = Coach.returnCoach();
        for(int j=0; j<coach.size(); j++){
             String name = coach.get(j).getName();
            if (!uniqueNames.contains(name)) {
                uniqueNames.add(name);
                coachCombo.addItem(name);
                coachCombo.setSelectedItem(coach.get(j).getUserId()); 
            }
        }
        
        //Get User Role
        String role = User.getUserRole();
        int grade = Learner.getCurrentGradeLevel();
        if(role.equalsIgnoreCase(User.LEARNER)){
            grade_text.setVisible(true);
            grade_value.setVisible(true);
            bookClass.setVisible(true);
            learners.setVisible(false);
            grade_value.setText(String.valueOf(grade));
        }else{
            grade_text.setVisible(false);
            grade_value.setVisible(false);
            bookClass.setVisible(false);
            learners.setVisible(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        booking = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        timetable = new javax.swing.JLabel();
        logout = new javax.swing.JLabel();
        rating = new javax.swing.JLabel();
        learners = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listing = new javax.swing.JTable();
        search = new javax.swing.JButton();
        coachCombo = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        gradeCombo = new javax.swing.JComboBox<>();
        bookClass = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        dayCombo = new javax.swing.JComboBox<>();
        grade_text = new javax.swing.JLabel();
        grade_value = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        booking.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        booking.setForeground(new java.awt.Color(0, 51, 102));
        booking.setText("Bookings");
        booking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookingMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("HJSS");

        timetable.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        timetable.setForeground(new java.awt.Color(0, 51, 102));
        timetable.setText("Timetable");
        timetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                timetableMouseClicked(evt);
            }
        });

        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 51, 102));
        logout.setText("Logout");
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });

        rating.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        rating.setForeground(new java.awt.Color(0, 51, 102));
        rating.setText("Ratings");
        rating.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ratingMouseClicked(evt);
            }
        });

        learners.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        learners.setForeground(new java.awt.Color(0, 51, 102));
        learners.setText("Learners");
        learners.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                learnersMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(learners, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timetable, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rating, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(booking, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel4)
                .addGap(44, 44, 44)
                .addComponent(learners)
                .addGap(30, 30, 30)
                .addComponent(timetable)
                .addGap(32, 32, 32)
                .addComponent(booking)
                .addGap(38, 38, 38)
                .addComponent(rating)
                .addGap(41, 41, 41)
                .addComponent(logout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Timetable");

        listing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lesson Code", "Grade Level", "Name", "Day", "Slot", "Date", "Available Seats", "Taken By"
            }
        ));
        jScrollPane1.setViewportView(listing);

        search.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        search.setForeground(new java.awt.Color(0, 0, 102));
        search.setText("Search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        coachCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Coach", " " }));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Grade Level");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Day ");

        gradeCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Grade Level", "1", "2", "3", "4", "5" }));

        bookClass.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        bookClass.setForeground(new java.awt.Color(0, 0, 102));
        bookClass.setText("Book Lesson");
        bookClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookClassActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Coach");

        dayCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Day", "Monday", "Wednesday", "Friday", "Saturday" }));

        grade_text.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        grade_text.setForeground(new java.awt.Color(255, 255, 255));
        grade_text.setText("Your Current Grade Level is  :");

        grade_value.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        grade_value.setForeground(new java.awt.Color(255, 255, 255));
        grade_value.setText("2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 861, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dayCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(coachCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(gradeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(grade_text, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(grade_value, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)))
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(586, Short.MAX_VALUE)
                    .addComponent(bookClass, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(373, 373, 373)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(grade_text, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(grade_value, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 131, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(99, 99, 99))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(coachCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)
                            .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(gradeCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(dayCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(667, Short.MAX_VALUE)
                    .addComponent(bookClass, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(24, 24, 24)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void timetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_timetableMouseClicked
        ViewTimetableJFrame frame = new ViewTimetableJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_timetableMouseClicked

    private void bookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookingMouseClicked
        ViewBookingJFrame frame = new ViewBookingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_bookingMouseClicked

    private void ratingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ratingMouseClicked
        ViewRatingJFrame frame = new ViewRatingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ratingMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        List<Admin> adminList = Admin.returnAdmin();       
        List<Learner> learnerList = Learner.returnLearners();

        for (Learner learner : learnerList) {
            if (learner.getIsLoggedIn() == 1) {
                learner.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
        for (Admin admin : adminList) {
            if (admin.getIsLoggedIn() == 1) {
                admin.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
    }//GEN-LAST:event_logoutMouseClicked

    /**
     * Search Timetable
     * @param evt 
     */
    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        String selected_day = String.valueOf(dayCombo.getSelectedItem());
        String selected_grade = String.valueOf(gradeCombo.getSelectedItem());

        String selectedName = String.valueOf(coachCombo.getSelectedItem());
        
        //  Get Coach Id from name
        int selected_coach = 0;
        Coach selectedCoach = null;
        List<Coach> coaches = Coach.returnCoach();
        for (Coach coach : coaches) {
            if (coach.getName().equals(selectedName)) {
                selectedCoach = coach;
                break;
            }
        }

        if (selectedCoach != null) {
            selected_coach = selectedCoach.getUserId();
        }


        DefaultTableModel model = (DefaultTableModel) listing.getModel();
        listing.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        model.setRowCount(0);
        
        Lesson.loadTimetable(model,selected_coach,selected_day,selected_grade);
       
    }//GEN-LAST:event_searchActionPerformed

    
    /**
     * Book a Lesson
     * @param evt 
     */
    private void bookClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookClassActionPerformed
      
        int record = listing.getSelectedRow();

        //If no row selected 
        if(record < 0){
            JOptionPane.showMessageDialog(null, "Select Lesson to Book Class");
            return;
        }

        //If row selected 
        if (record >= 0) {

            String lessonCode = String.valueOf(listing.getValueAt(record,0));
            String seats = String.valueOf(listing.getValueAt(record,6));
            String selectedGrade = String.valueOf(listing.getValueAt(record,1));
            int userId = User.LOGGED_IN_USER;
            String bookingNo = Booking.generateBookingNo();
            
            // If no vacancy
            if(Integer.parseInt(seats) <= 0){
               JOptionPane.showMessageDialog(null, "No Seat Available!");
               return;
            }
            
            //Check Grade Level of user
            int grade = Learner.getCurrentGradeLevel();
            if(Integer.parseInt(selectedGrade) > (grade+1)){
               JOptionPane.showMessageDialog(null, "Selected Grade Level is higher than your current grade level!");
               return;
            }else if(Integer.parseInt(selectedGrade) < grade){
               JOptionPane.showMessageDialog(null, "Selected Grade Level is lower than your current grade level!");
               return;
            }
            
            //Check Already Booked Leasson or not
            boolean isAlreadyBooked = Booking.isAlreadyBooked(lessonCode,userId);
            if(isAlreadyBooked){
               JOptionPane.showMessageDialog(null, "Already Booked Lesson!");
               return;
            }
            
            // Add Booking
            if(Booking.IS_CHANGING_BOOKING == 0){            
                Booking obj = new Booking(bookingNo,lessonCode,userId,Booking.BOOKED);
                Booking.bookingList.add(obj);
            // Change Booking
            }else if(Booking.IS_CHANGING_BOOKING == 1){            
                List<Booking> bookingList = Booking.returnBookings();
                List<Lesson> lessonList = Lesson.returnLessons();
                
                for(int i=0; i<bookingList.size(); i++){
                    if(bookingList.get(i).getBookingNo().equalsIgnoreCase(Booking.CHANGING_BOOKING_NO)){
                       
                        String lessonName = bookingList.get(i).getLessonCode();

                        //Increase Seats in previous selected lesson - when changed lesson
                        for(int j=0; j<lessonList.size(); j++){
                            if(lessonList.get(j).getLessonCode().equalsIgnoreCase(lessonName)){
                                int existingSeats = lessonList.get(j).getAvailableSeats();                                
                                lessonList.get(j).setAvailableSeats(existingSeats+1);
                            }
                        }
                        bookingList.get(i).setLessonCode(lessonCode);
                        bookingList.get(i).setStatus(Booking.CHANGED);
                    }
                }
            }
            
            if(Booking.IS_CHANGING_BOOKING == 0){
               JOptionPane.showMessageDialog(null, "Booked Successfully!");
            }else{
                Booking.IS_CHANGING_BOOKING = 0;
                Booking.CHANGING_BOOKING_NO = "";
               JOptionPane.showMessageDialog(null, "Changed Successfully!");
            }
            
            // Update Seats in Timetable
            List<Lesson> lessonList = Lesson.returnLessons();
            for(int i=0; i<lessonList.size(); i++){
                if(lessonList.get(i).getLessonCode().equalsIgnoreCase(lessonCode)){
                    lessonList.get(i).setAvailableSeats((lessonList.get(i).getAvailableSeats())-1);
                }
            }
       
            //Redirect to Booking List
            ViewBookingJFrame frame = new ViewBookingJFrame();
            frame.setVisible(true);
            this.setVisible(false);
        }
    }//GEN-LAST:event_bookClassActionPerformed

    private void learnersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_learnersMouseClicked
        ViewLearnerJFrame frame = new ViewLearnerJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_learnersMouseClicked

   
    /**
     * Main Method
     * @param args 
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewTimetableJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bookClass;
    private javax.swing.JLabel booking;
    private javax.swing.JComboBox<String> coachCombo;
    private javax.swing.JComboBox<String> dayCombo;
    private javax.swing.JComboBox<String> gradeCombo;
    private javax.swing.JLabel grade_text;
    private javax.swing.JLabel grade_value;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel learners;
    private javax.swing.JTable listing;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel rating;
    private javax.swing.JButton search;
    private javax.swing.JLabel timetable;
    // End of variables declaration//GEN-END:variables
}
