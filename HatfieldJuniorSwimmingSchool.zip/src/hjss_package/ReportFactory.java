
package hjss_package;

public class ReportFactory {
    public Report createReport(String reportType) {
        if (reportType.equalsIgnoreCase("Coach")) {
            return new CoachReport();
        } else if (reportType.equalsIgnoreCase("Learner")) {
            return new LearnerReport();
        }
        return null;
    }
}
