
package hjss_package;


public abstract class Report {
   abstract void exportReport();
}
