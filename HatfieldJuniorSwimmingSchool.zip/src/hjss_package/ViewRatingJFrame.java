
package hjss_package;

import java.awt.Container;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;


public class ViewRatingJFrame extends javax.swing.JFrame {

    
    public ViewRatingJFrame() {
        initComponents();        
        
        // View Booking detail to add review
        String bookingNo = Rating.ATTENDING_BOOKING_NO;
        
        //Hide or show attend button
        if(bookingNo.equalsIgnoreCase("")){
            attend.setVisible(false);
        }else{
            attend.setVisible(true);
        }
        
        String role = User.getUserRole();
        if(role.equalsIgnoreCase(User.LEARNER)){
            learners.setVisible(false);
            
            bookinglabel.setVisible(true);
            reviewlabel.setVisible(true);
            ratinglabel.setVisible(true);
            coachlabel.setVisible(true);
            lessonlabel.setVisible(true);
            slotlabel.setVisible(true);
            daylabel.setVisible(true);
            
            bookingNum.setVisible(true);
            review.setVisible(true);
            ratings.setVisible(true);
            coach.setVisible(true);
            lesson.setVisible(true);
            slot.setVisible(true);
            day.setVisible(true);
            heading.setVisible(true);
        }else{
            learners.setVisible(true);
            bookinglabel.setVisible(false);
            reviewlabel.setVisible(false);
            ratinglabel.setVisible(false);
            coachlabel.setVisible(false);
            lessonlabel.setVisible(false);
            slotlabel.setVisible(false);
            daylabel.setVisible(false);
            
            bookingNum.setVisible(false);
            ratings.setVisible(false);
            coach.setVisible(false);
            lesson.setVisible(false);
            slot.setVisible(false);
            day.setVisible(false);
            Container parent = review.getParent();
            parent.remove(review);
            parent.revalidate();
            parent.repaint();
            review.setBorder(null);
            review.setSize(0, 0);
            heading.setVisible(false);
        }
        
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();

        if(bookingNo != ""){
            for(int i=0; i<bookingList.size(); i++){
                if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
                    for(int j=0; j<lessonList.size(); j++){
                        if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                            for(int k=0; k<coachList.size(); k++){
                                if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                                    coach.setText(coachList.get(k).getName());
                                }
                            }
                            bookingNum.setText(bookingNo);
                            lesson.setText(lessonList.get(j).getName());
                            day.setText(lessonList.get(j).getDay());
                            slot.setText(lessonList.get(j).getSlot());
                            day.setEditable(false);
                            lesson.setEditable(false);
                            slot.setEditable(false);
                            coach.setEditable(false);
                            bookingNum.setEditable(false);
                        }
                    }
                }
            }
        }
        
        // View Rating list
        DefaultTableModel model = (DefaultTableModel) listing.getModel();
        listing.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        listing.setDefaultEditor(Object.class, null);
        
        Rating.viewRatings(model,role);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        booking = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        timetable = new javax.swing.JLabel();
        logout = new javax.swing.JLabel();
        rating = new javax.swing.JLabel();
        learners = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listing = new javax.swing.JTable();
        coachlabel = new javax.swing.JLabel();
        daylabel = new javax.swing.JLabel();
        day = new javax.swing.JTextField();
        lessonlabel = new javax.swing.JLabel();
        bookingNum = new javax.swing.JTextField();
        coach = new javax.swing.JTextField();
        slotlabel = new javax.swing.JLabel();
        slot = new javax.swing.JTextField();
        bookinglabel = new javax.swing.JLabel();
        ratinglabel = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        review = new javax.swing.JTextArea();
        ratings = new javax.swing.JComboBox<>();
        attend = new javax.swing.JButton();
        heading = new javax.swing.JLabel();
        reviewlabel = new javax.swing.JLabel();
        lesson = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        booking.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        booking.setForeground(new java.awt.Color(0, 51, 102));
        booking.setText("Bookings");
        booking.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookingMouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("HJSS");

        timetable.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        timetable.setForeground(new java.awt.Color(0, 51, 102));
        timetable.setText("Timetable");
        timetable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                timetableMouseClicked(evt);
            }
        });

        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(0, 51, 102));
        logout.setText("Logout");
        logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutMouseClicked(evt);
            }
        });

        rating.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        rating.setForeground(new java.awt.Color(0, 51, 102));
        rating.setText("Ratings");
        rating.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ratingMouseClicked(evt);
            }
        });

        learners.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        learners.setForeground(new java.awt.Color(0, 51, 102));
        learners.setText("Learners");
        learners.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                learnersMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(learners, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timetable, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rating, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(booking, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel4)
                .addGap(39, 39, 39)
                .addComponent(learners)
                .addGap(35, 35, 35)
                .addComponent(timetable)
                .addGap(34, 34, 34)
                .addComponent(booking)
                .addGap(36, 36, 36)
                .addComponent(rating)
                .addGap(36, 36, 36)
                .addComponent(logout)
                .addContainerGap(461, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Ratings");

        listing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BookingNo", "Lesson Name", "Grade Level", "Rating", "Review", "Given To", "Given By"
            }
        ));
        jScrollPane1.setViewportView(listing);

        coachlabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        coachlabel.setForeground(new java.awt.Color(255, 255, 255));
        coachlabel.setText("Coach : ");

        daylabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        daylabel.setForeground(new java.awt.Color(255, 255, 255));
        daylabel.setText("Day :");

        lessonlabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lessonlabel.setForeground(new java.awt.Color(255, 255, 255));
        lessonlabel.setText("Lesson : ");

        slotlabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        slotlabel.setForeground(new java.awt.Color(255, 255, 255));
        slotlabel.setText("Slot :");

        bookinglabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bookinglabel.setForeground(new java.awt.Color(255, 255, 255));
        bookinglabel.setText("BookingNo :");

        ratinglabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ratinglabel.setForeground(new java.awt.Color(255, 255, 255));
        ratinglabel.setText("Rating :");

        review.setColumns(20);
        review.setRows(5);
        jScrollPane2.setViewportView(review);

        ratings.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Rating", "1 (Very dissatisfied)", "2 (Dissatisfied)", "3 (Ok)", "4 (Satisfied)", "5 (Very Satisfied)" }));

        attend.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        attend.setForeground(new java.awt.Color(0, 0, 102));
        attend.setText("Attend");
        attend.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                attendMouseClicked(evt);
            }
        });

        heading.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        heading.setForeground(new java.awt.Color(255, 255, 255));
        heading.setText("Give Rating To Coach To Attend Lesson : ");

        reviewlabel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        reviewlabel.setForeground(new java.awt.Color(255, 255, 255));
        reviewlabel.setText("Review :");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(attend, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(coachlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ratinglabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(reviewlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bookinglabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(coach)
                                    .addComponent(ratings, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bookingNum, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(64, 64, 64)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(slotlabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                                            .addComponent(daylabel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addComponent(lessonlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lesson)
                            .addComponent(day)
                            .addComponent(slot, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 861, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(heading, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3)
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(heading)
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bookingNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bookinglabel)
                    .addComponent(lessonlabel)
                    .addComponent(lesson, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(coachlabel)
                    .addComponent(coach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(day, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(daylabel))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ratinglabel)
                    .addComponent(ratings, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(slotlabel))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reviewlabel))
                .addGap(30, 30, 30)
                .addComponent(attend, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 805, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void timetableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_timetableMouseClicked
        ViewTimetableJFrame frame = new ViewTimetableJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_timetableMouseClicked

    private void bookingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookingMouseClicked
        ViewBookingJFrame frame = new ViewBookingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_bookingMouseClicked

    private void ratingMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ratingMouseClicked
        ViewRatingJFrame frame = new ViewRatingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_ratingMouseClicked

    private void logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutMouseClicked
        List<Admin> adminList = Admin.returnAdmin();       
        List<Learner> learnerList = Learner.returnLearners();

        for (Learner learner : learnerList) {
            if (learner.getIsLoggedIn() == 1) {
                learner.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
        for (Admin admin : adminList) {
            if (admin.getIsLoggedIn() == 1) {
                admin.setIsLoggedIn(0);
                HomepageJFrame frame = new HomepageJFrame();
                frame.setVisible(true);
                this.setVisible(false);
            }
        }
    }//GEN-LAST:event_logoutMouseClicked

    private void attendMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_attendMouseClicked
        String rating = ratings.getSelectedItem().toString();
        int ratingNum = ratings.getSelectedIndex();
        String reviews = review.getText();
        if(rating.equalsIgnoreCase("Select Rating") || reviews.equalsIgnoreCase("")){
             JOptionPane.showMessageDialog(null, "Fields are required");
             return;
        }
                
        String bookingNo = Rating.ATTENDING_BOOKING_NO;
        
        //Get coach id
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        List<Learner> leanerList = Learner.returnLearners();
        
        int coach = 0;
        int attendedLessonGrade = 0;
        for(int i=0; i<bookingList.size(); i++){     
           if(bookingList.get(i).getBookingNo().equalsIgnoreCase(bookingNo)){
              
               // get Lesson Details
               for(int j=0; j<lessonList.size(); j++){
                   if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                       for(int k=0; k<coachList.size(); k++){
                           if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                               coach = coachList.get(k).getUserId();
                           }
                       }
                       attendedLessonGrade = lessonList.get(j).getGradeLevel();

                       //Increase Seats when attended lesson
                       lessonList.get(j).setAvailableSeats(lessonList.get(j).getAvailableSeats()+1);
                   }
               }
               //Update status of booking
               bookingList.get(i).setStatus(Booking.ATTENDED);
           }
        }
        
        Rating obj = new Rating(bookingNo,ratingNum,reviews,User.LOGGED_IN_USER,coach);
        Rating.ratingList.add(obj);
        JOptionPane.showMessageDialog(null, "Attended Successfully!");
        
        // Increase Grade Level of Learner after attending lesson of higher level
        for(int i=0; i<leanerList.size(); i++){     
            if(leanerList.get(i).getUserId() == User.LOGGED_IN_USER){
                int currentGrade = Learner.getCurrentGradeLevel();
                if(attendedLessonGrade > currentGrade){
                    leanerList.get(i).setGradeLevel((leanerList.get(i).getGradeLevel())+1);
                }
                break;
            }
        }
     
        Rating.ATTENDING_BOOKING_NO = "";
        
        ViewRatingJFrame frame = new ViewRatingJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_attendMouseClicked

    private void learnersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_learnersMouseClicked
        ViewLearnerJFrame frame = new ViewLearnerJFrame();
        frame.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_learnersMouseClicked

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewRatingJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton attend;
    private javax.swing.JLabel booking;
    private javax.swing.JTextField bookingNum;
    private javax.swing.JLabel bookinglabel;
    private javax.swing.JTextField coach;
    private javax.swing.JLabel coachlabel;
    private javax.swing.JTextField day;
    private javax.swing.JLabel daylabel;
    private javax.swing.JLabel heading;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel learners;
    private javax.swing.JTextField lesson;
    private javax.swing.JLabel lessonlabel;
    private javax.swing.JTable listing;
    private javax.swing.JLabel logout;
    private javax.swing.JLabel rating;
    private javax.swing.JLabel ratinglabel;
    private javax.swing.JComboBox<String> ratings;
    private javax.swing.JTextArea review;
    private javax.swing.JLabel reviewlabel;
    private javax.swing.JTextField slot;
    private javax.swing.JLabel slotlabel;
    private javax.swing.JLabel timetable;
    // End of variables declaration//GEN-END:variables
}
