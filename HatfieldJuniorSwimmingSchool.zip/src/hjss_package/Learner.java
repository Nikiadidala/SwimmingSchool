
package hjss_package;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.swing.table.DefaultTableModel;


public class Learner extends User{
    
    private int gradeLevel;

    public static ArrayList <Learner> learnerList = new ArrayList<>();

    public Learner(int gradeLevel, int userId, String name, String username, String password, String gender, int age, String contact, String role, int isLoggedIn) {
        super(userId, name, username, password, gender, age, contact, role, isLoggedIn);
        this.gradeLevel = gradeLevel;
    }

    public int getGradeLevel() {
        return gradeLevel;
    }
        
    public void setGradeLevel(int gradeLevel) {
        this.gradeLevel = gradeLevel;
    }
    
    public static List returnLearners() {
        
        Learner obj1 = new Learner(0,6,"Tiffany Matthews","tiffany","tiffany","Male",4,"01327 892000",LEARNER,0);
        Learner obj2 = new Learner(2,7,"Tina Wright","tina","tina","Female",11,"01590 672050",LEARNER,0);
        Learner obj3 = new Learner(3,8,"Wayne Young","wayne","wayne","Male",9,"01473 231944",LEARNER,0);
        Learner obj4 = new Learner(4,10,"Tanya Watson","tanya","tanya","Female",7,"01792 369455",LEARNER,0);
        Learner obj5 = new Learner(5,11,"Ava Evans","ava","ava","Female",11,"0191 477 2889",LEARNER,0);
        Learner obj6 = new Learner(1,12,"Olivia Baker","olivia","olivia","Male",5,"01494 520006",LEARNER,0);
        Learner obj7 = new Learner(2,13,"Bruce Kelly","bruce","bruce","Male",8,"01225 837671",LEARNER,0);
        Learner obj8 = new Learner(3,14,"Wayne Moore","wayne","wayne","Male",9,"01633 254835",LEARNER,0);
        Learner obj9 = new Learner(0,15,"Daisy Davis","daisy","daisy","Female",6,"0845 774 0740",LEARNER,0);
        Learner obj10 = new Learner(5,16,"Rob Marshall","rob","rob","Male",11,"0121 748 6063",LEARNER,0);
        Learner obj11 = new Learner(0,17,"Louis Thomas","louis","louis","Male",5,"0121 783 7177",LEARNER,0);
        Learner obj12 = new Learner(2,18,"Arthur Moore","arthur","arthur","Male",8,"01924 454116",LEARNER,0);
        Learner obj13 = new Learner(3,19,"Sonia Young","sonia","sonia","Female",6,"01623 629359",LEARNER,0);
        Learner obj14 = new Learner(4,20,"Steve Mitchell","steve","steve","Male",8,"01724 282233",LEARNER,0);
        Learner obj15 = new Learner(0,21,"Teagan Morgan","teagan","teagan","Male",5,"01623 651129",LEARNER,0);
        
        learnerList.add(obj1);
        learnerList.add(obj2);
        learnerList.add(obj3);
        learnerList.add(obj4);
        learnerList.add(obj5);
        learnerList.add(obj6);
        learnerList.add(obj7);
        learnerList.add(obj8);
        learnerList.add(obj9);
        learnerList.add(obj10);
        learnerList.add(obj11);
        learnerList.add(obj12);
        learnerList.add(obj13);
        learnerList.add(obj14);
        learnerList.add(obj15);
        
        return learnerList;
    }
    
    
    /**
     * Get Current Grade level of Learner
     * @return 
     */
    public static int getCurrentGradeLevel(){
        List<Learner> learnerList = Learner.returnLearners();
        int grade_level = 0;

        for (Learner learner : learnerList) {
            if (learner.getIsLoggedIn() == 1) {
                grade_level = learner.getGradeLevel();
            }
        }
        
        return grade_level;
    }
    
    
    
    /**
     * Check username already exists or not
     * @return 
     */
    public static boolean isUsernameExist(String username){
        List<Learner> learnerList = Learner.returnLearners();

        for (Learner learner : learnerList) {
            if (learner.getUsername().equalsIgnoreCase(username)) {
                return true;
            }
        }
        return false;
    }
    
    
        
    
    /**
     * View Learner
     * @param args 
     */
    public static void viewLearners(DefaultTableModel model, String role){
        
        List<Learner> learnerList = Learner.returnLearners();
        model.setRowCount(0);
        Set<String> uniqueRows = new HashSet<>();
        
         for(int j=0; j<learnerList.size(); j++){
             String key = learnerList.get(j).getUserId() + learnerList.get(j).getGradeLevel() + learnerList.get(j).getUsername()+ learnerList.get(j).getName() + 
                    learnerList.get(j).getContact() + learnerList.get(j).getAge() + learnerList.get(j).getGender();
             
            // get Learner Deatils
            String userID = "";
            String user_name = "";
            String username = "";
            String gender = "";
            String age = "";
            String grade = "";
            String contact = "";

            if(uniqueRows.add(key)){
                
                userID = String.valueOf(learnerList.get(j).getUserId());
                grade = String.valueOf(learnerList.get(j).getGradeLevel());
                age = String.valueOf(learnerList.get(j).getAge());
                contact = learnerList.get(j).getContact();
                username = learnerList.get(j).getUsername();
                gender = learnerList.get(j).getGender();
                user_name = learnerList.get(j).getName();

                String[] arr = {userID,user_name,username,gender,age,contact,grade};
                model.addRow(arr);
            }
         }        
    }
    
    
     /**
      * Generate Random UserId
      * @return 
      */
    public static int generateUserId(){
        Random random = new Random();
        int randomNumber = random.nextInt(100);
        return randomNumber;
    }
}
