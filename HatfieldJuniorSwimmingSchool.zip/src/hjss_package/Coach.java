
package hjss_package;

import java.util.ArrayList;
import java.util.List;


public class Coach extends User {
      
    private String joinedAt;
    
    public static ArrayList <Coach> coachList = new ArrayList<>();

    public Coach(String joinedAt, int userId, String name, String username, String password, String gender, int age, String contact, String role, int isLoggedIn) {
        super(userId, name, username, password, gender, age, contact, role,isLoggedIn);
        this.joinedAt = joinedAt;
    }

  
    public static List returnCoach() {
        
        Coach obj1 = new Coach("12Dec,2023",1,"William","william","william","Male",40,"01202 682247",COACH,0);
        Coach obj2 = new Coach("28Dec,2023",2,"Samuel Cook","samuel","samuel","Male",35,"01258 455707",COACH,0);
        Coach obj3 = new Coach("10Nov,2023",3,"Duncan Powell","duncan","duncan","Male",32,"0844 488 5097",COACH,0);
        Coach obj4 = new Coach("24July,2023",4,"Tony Allen","tony","tony","Male",34,"0151 334 5216",COACH,0);
        Coach obj5 = new Coach("28Aug,2023",5,"Ethan Anderson","ethan","ethan","Male",40,"01202 682247",COACH,0);
        coachList.add(obj1);
        coachList.add(obj2);
        coachList.add(obj3);
        coachList.add(obj4);
        coachList.add(obj5);
        return coachList;
    }
}
