
package hjss_package;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.table.DefaultTableModel;

public class Booking {
    
    private String bookingNo;
    private String lessonCode;
    private int userId;
    private String status;
    
    public static String BOOKED = "Booked";
    public static String CHANGED = "Changed";
    public static String CANCELLED = "Cancelled";
    public static String ATTENDED = "Attended";
    
    public static int IS_CHANGING_BOOKING = 0;
    public static String CHANGING_BOOKING_NO = "";

   public static ArrayList <Booking> bookingList = new ArrayList<>();

    public Booking(String bookingNo, String lessonCode, int userId, String status) {
        this.bookingNo = bookingNo;
        this.lessonCode = lessonCode;
        this.userId = userId;
        this.status = status;
    }

    public String getBookingNo() {
        return bookingNo;
    }
    
    public String getLessonCode() {
        return lessonCode;
    }

    public int getUserId() {
        return userId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setLessonCode(String lessonCode) {
        this.lessonCode = lessonCode;
    }
    
    public static List returnBookings() {
        return bookingList;
    }
    
    /**
     * Generate booking no
     * @return 
     */
    public static String generateBookingNo(){
        Random random = new Random();
        int randomNumber = random.nextInt(100000);
        String bookingNo = "HJJS_No_"+randomNumber;
        return bookingNo;
    }
    
    
      /**
     * View User Bookings
     * @param args 
     */
    public static void viewUserBookings(DefaultTableModel model, String role){
        
        List<Booking> bookingList = Booking.returnBookings();
        List<Lesson> lessonList = Lesson.returnLessons();
        List<Coach> coachList = Coach.returnCoach();
        List<Learner> learnerList = Learner.returnLearners();
                
         for(int i=0; i<bookingList.size(); i++){
             
            String slot = "";
            String date = "";
            String day = "";
            String grade = "";
            String name = "";
            String coach = "";
            String username = "";
            String user_contact = "";
            
            if(role.equalsIgnoreCase(User.LEARNER)){
                
                if(bookingList.get(i).getUserId() == User.LOGGED_IN_USER){

                    // get Lesson Deatils
                    for(int j=0; j<lessonList.size(); j++){

                        if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                            slot = lessonList.get(j).getSlot();
                            date = lessonList.get(j).getDate();
                            day = lessonList.get(j).getDay();
                            grade = String.valueOf(lessonList.get(j).getGradeLevel());
                            name = lessonList.get(j).getName();

                            for(int k=0; k<coachList.size(); k++){
                                if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                                    coach = coachList.get(k).getName();
                                }
                            }
                        }
                    }

                    //Get user detail
                    for(int x=0; x<learnerList.size(); x++){
                        if(learnerList.get(x).getUserId() == bookingList.get(i).getUserId()){
                            username = learnerList.get(x).getName();
                            user_contact = learnerList.get(x).getContact();
                        }
                    }

                    String bookingNo = bookingList.get(i).getBookingNo();
                    String status = bookingList.get(i).getStatus();

                    String[] arr = {bookingNo,username,user_contact,name,date,day,slot, grade, status,coach};
                    model.addRow(arr);
                }
            }else{
                // get Lesson Deatils
                for(int j=0; j<lessonList.size(); j++){

                    if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                        slot = lessonList.get(j).getSlot();
                        date = lessonList.get(j).getDate();
                        day = lessonList.get(j).getDay();
                        grade = String.valueOf(lessonList.get(j).getGradeLevel());
                        name = lessonList.get(j).getName();

                        for(int k=0; k<coachList.size(); k++){
                            if(coachList.get(k).getUserId() == lessonList.get(j).getTaughtBy()){
                                coach = coachList.get(k).getName();
                            }
                        }
                    }
                }

                //Get user detail
                for(int x=0; x<learnerList.size(); x++){
                    if(learnerList.get(x).getUserId() == bookingList.get(i).getUserId()){
                        username = learnerList.get(x).getName();
                        user_contact = learnerList.get(x).getContact();
                    }
                }

                String bookingNo = bookingList.get(i).getBookingNo();
                String status = bookingList.get(i).getStatus();

                String[] arr = {bookingNo,username,user_contact,name,date,day,slot, grade, status,coach};
                model.addRow(arr);
            }
         }        
    }
    
     
    /**
     * Check whether the lesson is already booked by the user
     * @param lessonCode
     * @param userId
     * @return 
     */
    public static boolean isAlreadyBooked(String lessonCode, int userId){
        List<Booking> bookingList = Booking.returnBookings();

        for(Booking obj : bookingList){
            if(obj.getLessonCode().equalsIgnoreCase(lessonCode) && obj.getUserId() == userId && (obj.getStatus().equalsIgnoreCase(Booking.BOOKED) 
                    || obj.getStatus().equalsIgnoreCase(Booking.CHANGED))){
                return true;
            }
        }
        return false;
    }
    
}
