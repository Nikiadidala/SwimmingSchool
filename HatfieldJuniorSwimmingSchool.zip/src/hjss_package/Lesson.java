
package hjss_package;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.table.DefaultTableModel;


public class Lesson {
    
     private String lessonCode;
     private int gradeLevel;
     private String name;
     private String day;
     private String slot;
     private String date;
     private int availableSeats;
     private int taughtBy;
          
    public static ArrayList <Lesson> lessonList = new ArrayList<>();

    public Lesson(String lessonCode, int gradeLevel, String name, String day, String slot, String date, int availableSeats, int taughtBy) {
        this.lessonCode = lessonCode;
        this.gradeLevel = gradeLevel;
        this.name = name;
        this.day = day;
        this.slot = slot;
        this.date = date;
        this.availableSeats = availableSeats;
        this.taughtBy = taughtBy;
    }

    public String getLessonCode() {
        return lessonCode;
    }

    public int getGradeLevel() {
        return gradeLevel;
    }

    public String getName() {
        return name;
    }

    public String getDay() {
        return day;
    }

    public String getSlot() {
        return slot;
    }

    public String getDate() {
        return date;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public int getTaughtBy() {
        return taughtBy;
    }

    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
     
    
    public static List returnLessons() {
        
        // first week
        Lesson obj1 = new Lesson("lesson001",1,"Water Safety","Monday","4-5 pm","1April,2024",4,1);
        Lesson obj2 = new Lesson("lesson002",2,"Breathing Techniques","Monday","5-6 pm","1April,2024",4,2);
        Lesson obj3 = new Lesson("lesson003",3,"Body Position","Monday","6-7 pm","1April,2024",4,3);
        
        Lesson obj4 = new Lesson("lesson004",1,"Stroke Drills","Wednesday","4-5 pm","3April,2024",4,4);
        Lesson obj5 = new Lesson("lesson005",4,"Streamlining","Wednesday","5-6 pm","3April,2024",4,5);
        Lesson obj6 = new Lesson("lesson006",5,"Endurance Training","Wednesday","6-7 pm","3April,2024",4,1);
        
        Lesson obj7 = new Lesson("lesson007",2,"Kicking Technique","Friday","4-5 pm","5April,2024",4,2);
        Lesson obj8 = new Lesson("lesson008",3,"Arm Movement","Friday","5-6 pm","5April,2024",4,3);
        Lesson obj9 = new Lesson("lesson009",5,"Practice Consistency","Friday","6-7 pm","5April,2024",4,1);
        
        Lesson obj10 = new Lesson("lesson010",4,"Develop Efficient Strokes","Saturday","2-3 pm","6April,2024",4,1);
        Lesson obj11 = new Lesson("lesson011",2,"Improve Flexibility","Saturday","3-4 pm","6April,2024",4,2);
        
        
        // second week
        Lesson obj12 = new Lesson("lesson012",4,"Kicking Technique","Monday","4-5 pm","8April,2024",4,1);
        Lesson obj13 = new Lesson("lesson013",5,"Arm Movement","Monday","5-6 pm","8April,2024",4,2);
        Lesson obj14 = new Lesson("lesson014",1,"Practice Consistency","Monday","6-7 pm","8April,2024",4,3);
        
        Lesson obj15 = new Lesson("lesson015",3,"Develop Efficient Strokes","Wednesday","4-5 pm","10April,2024",4,4);
        Lesson obj16 = new Lesson("lesson016",2,"Improve Flexibility","Wednesday","5-6 pm","10April,2024",4,5);
        Lesson obj17 = new Lesson("lesson017",1,"Endurance Training","Wednesday","6-7 pm","10April,2024",4,1);
        
        Lesson obj18 = new Lesson("lesson018",2,"Water Safety","Friday","4-5 pm","12April,2024",4,2);
        Lesson obj19 = new Lesson("lesson019",3,"Breathing Techniques","Friday","5-6 pm","12April,2024",4,3);
        Lesson obj20 = new Lesson("lesson020",1,"Body Position","Friday","6-7 pm","12April,2024",4,1);
        
        Lesson obj21 = new Lesson("lesson021",1,"Stroke Drills","Saturday","2-3 pm","13April,2024",4,1);
        Lesson obj22 = new Lesson("lesson022",5,"Streamlining","Saturday","3-4 pm","13April,2024",4,2);
        
        
        
        // third week
        Lesson obj23 = new Lesson("lesson023",3,"Stroke Drills","Monday","4-5 pm","15April,2024",4,1);
        Lesson obj24 = new Lesson("lesson024",4,"Streamlining","Monday","5-6 pm","15April,2024",4,2);
        Lesson obj25 = new Lesson("lesson025",2,"Develop Efficient Strokes","Monday","6-7 pm","15April,2024",4,3);
        
        Lesson obj26 = new Lesson("lesson026",4,"Arm Movement","Wednesday","4-5 pm","17April,2024",4,4);
        Lesson obj27 = new Lesson("lesson027",5,"Body Position","Wednesday","5-6 pm","17April,2024",4,5);
        Lesson obj28 = new Lesson("lesson028",2,"Kicking Technique","Wednesday","6-7 pm","17April,2024",4,1);
        
        Lesson obj29 = new Lesson("lesson029",4,"Improve Flexibility","Friday","4-5 pm","19April,2024",4,2);
        Lesson obj30 = new Lesson("lesson030",5,"Practice Consistency","Friday","5-6 pm","19April,2024",4,3);
        Lesson obj31 = new Lesson("lesson031",2,"Breathing Techniques","Friday","6-7 pm","19April,2024",4,1);
        
        Lesson obj32 = new Lesson("lesson032",3,"Water Safety","Saturday","2-3 pm","20April,2024",4,1);
        Lesson obj33 = new Lesson("lesson033",1,"Endurance Training","Saturday","3-4 pm","20April,2024",4,2);
        
        
          
        // fourth week
        Lesson obj34 = new Lesson("lesson034",5,"Endurance Training","Monday","4-5 pm","22April,2024",4,1);
        Lesson obj35 = new Lesson("lesson035",1,"Body Position","Monday","5-6 pm","22April,2024",4,2);
        Lesson obj36 = new Lesson("lesson036",3,"Stroke Drills","Monday","6-7 pm","22April,2024",4,3);
        
        Lesson obj37 = new Lesson("lesson037",2,"Breathing Techniques","Wednesday","4-5 pm","24April,2024",4,4);
        Lesson obj38 = new Lesson("lesson038",3,"Streamlining","Wednesday","5-6 pm","24April,2024",4,5);
        Lesson obj39 = new Lesson("lesson039",1,"Endurance Training","Wednesday","6-7 pm","24April,2024",4,1);
        
        Lesson obj40 = new Lesson("lesson040",3,"Water Safety","Friday","4-5 pm","26April,2024",4,2);
        Lesson obj41 = new Lesson("lesson041",4,"Breathing Techniques","Friday","5-6 pm","26April,2024",4,3);
        Lesson obj42 = new Lesson("lesson042",5,"Develop Efficient Strokes","Friday","6-7 pm","26April,2024",4,1);
        
        Lesson obj43 = new Lesson("lesson043",5,"Stroke Drills","Saturday","2-3 pm","27April,2024",4,1);
        Lesson obj44 = new Lesson("lesson044",2,"Arm Movemen","Saturday","3-4 pm","27April,2024",4,2);

        lessonList.add(obj1);
        lessonList.add(obj2);
        lessonList.add(obj3);
        lessonList.add(obj4);
        lessonList.add(obj5);
        lessonList.add(obj6);
        lessonList.add(obj7);
        lessonList.add(obj8);
        lessonList.add(obj9);
        lessonList.add(obj10);
        lessonList.add(obj11);
        lessonList.add(obj12);
        lessonList.add(obj13);
        lessonList.add(obj14);
        lessonList.add(obj15);
        lessonList.add(obj16);
        lessonList.add(obj17);
        lessonList.add(obj18);
        lessonList.add(obj19);
        lessonList.add(obj20);
        lessonList.add(obj21);
        lessonList.add(obj22);
        lessonList.add(obj23);
        lessonList.add(obj24);
        lessonList.add(obj25);
        lessonList.add(obj26);
        lessonList.add(obj27);
        lessonList.add(obj28);
        lessonList.add(obj29);
        lessonList.add(obj30);
        lessonList.add(obj31);
        lessonList.add(obj32);
        lessonList.add(obj33);
        lessonList.add(obj34);
        lessonList.add(obj35);
        lessonList.add(obj36);
        lessonList.add(obj37);
        lessonList.add(obj38);
        lessonList.add(obj39);
        lessonList.add(obj40);
        lessonList.add(obj41);
        lessonList.add(obj42);
        lessonList.add(obj43);
        lessonList.add(obj44);
        return lessonList;
    }
    
    
    
    /**
     * Load Timetable into table
     * @param model
     * @param selected_coach
     * @param selected_day
     * @param selected_grade 
     */
    public static void loadTimetable(DefaultTableModel model,int selected_coach,String selected_day, String selected_grade){
     
        List<Lesson> lessons = Lesson.returnLessons();
        List<Coach> coach = Coach.returnCoach();
                
        model.setRowCount(0);
        
        Set<String> uniqueRows = new HashSet<>();
                
        for(int i=0; i<lessons.size(); i++){
            String key = lessons.get(i).getLessonCode() + lessons.get(i).getGradeLevel() + lessons.get(i).getName() + 
                    lessons.get(i).getDay() + lessons.get(i).getSlot() + lessons.get(i).getDate();
                        
            // If All Filter
            if (selected_coach != 0 && (selected_day != "Select Day" && !selected_day.isEmpty()) && (selected_grade != "Select Grade Level" && !selected_grade.isEmpty())) {
                if (lessons.get(i).getTaughtBy() == selected_coach && 
                    lessons.get(i).getDay().equals(selected_day) && 
                    String.valueOf(lessons.get(i).getGradeLevel()).equals(selected_grade) && 
                    uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                }
            // Coach & Day
            }else if (selected_coach != 0 && (selected_day != "Select Day" && !selected_day.isEmpty())) {
                if (lessons.get(i).getTaughtBy() == selected_coach && 
                    lessons.get(i).getDay().equals(selected_day) && 
                    uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                }
            }
            //Coach & Grade
            else if (selected_coach != 0 && (selected_grade != "Select Grade Level" && !selected_grade.isEmpty())) {
                if (lessons.get(i).getTaughtBy() == selected_coach && 
                    String.valueOf(lessons.get(i).getGradeLevel()).equals(selected_grade) && 
                    uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                }
            }
            //Day & Grade
            else if ((selected_day != "Select Day" && !selected_day.isEmpty()) && (selected_grade != "Select Grade Level" && !selected_grade.isEmpty())) {
                if (lessons.get(i).getDay() == selected_day && 
                    String.valueOf(lessons.get(i).getGradeLevel()).equals(selected_grade) && 
                    uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                }   
            // Coach Filter
            }else if (selected_coach != 0 && (selected_day.isEmpty() || selected_day == "Select Day") && (selected_grade.isEmpty() || selected_grade == "Select Grade Level")) {
                if (lessons.get(i).getTaughtBy() == selected_coach  && uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                }  
            }
            // Day Filter
            else if ((selected_day != "Select Day" && !selected_day.isEmpty()) && (selected_grade.isEmpty() || selected_grade == "Select Grade Level") && selected_coach == 0) {
                if (lessons.get(i).getDay() == selected_day && uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                } 
            }
            // Grade Filter
            else if ((selected_grade != "Select Grade Level" && !selected_grade.isEmpty()) && (selected_day.isEmpty() || selected_day == "Select Day") && selected_coach == 0) {
                if (String.valueOf(lessons.get(i).getGradeLevel()).equals(selected_grade) && uniqueRows.add(key)) {
                    // Add unique row to the set
                    addRowToModel(lessons.get(i), coach, model);
                } 
            // All Timetable By Default
            }
            else if ((selected_day.isEmpty() || selected_day == "Select Day") && selected_coach == 0 && (selected_grade.isEmpty() || selected_grade == "Select Grade Level") && uniqueRows.add(key)) {
                // Add unique row to the set
                addRowToModel(lessons.get(i), coach, model);
            }
        }
    }

    
    
    /**
     *  Function to add a row to the model
     * @param lesson
     * @param coachList
     * @param model 
     */
    private static void addRowToModel(Lesson lesson, List<Coach> coachList, DefaultTableModel model) {
        String coachName = coachList.stream()
                                    .filter(coach -> coach.getUserId() == lesson.getTaughtBy())
                                    .findFirst()
                                    .map(Coach::getName)
                                    .orElse("");

        String code = lesson.getLessonCode();
        String grade = String.valueOf(lesson.getGradeLevel());
        String day = lesson.getDay();
        String slot = lesson.getSlot();
        String seats = String.valueOf(lesson.getAvailableSeats());
        String date = lesson.getDate();

        String[] arr = {code, grade, lesson.getName(), day, slot, date, seats, coachName};
        model.addRow(arr);
    }
    
    
}
