
package hjss_package;

import java.util.ArrayList;
import java.util.List;

public class User {
    
    private int userId;
    private String name;
    private String username;
    private String password;
    private String gender;
    private int age;
    private String contact;
    private String role;
    private int isLoggedIn;
    
    // Constants of Role
    public static String COACH = "Coach";
    public static String LEARNER = "Learner";
    public static String ADMIN = "Admin";
    public static int LOGGED_IN_USER = 0;
    
    public static ArrayList <User> userList = new ArrayList<>();

    public User(int userId, String name, String username, String password, String gender, int age, String contact, String role, int isLoggedIn) {
        this.userId = userId;
        this.name = name;
        this.username = username;
        this.password = password;
        this.gender = gender;
        this.age = age;
        this.contact = contact;
        this.role = role;
        this.isLoggedIn = isLoggedIn;
    }

    public int getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public String getContact() {
        return contact;
    }

    public String getRole() {
        return role;
    }

    public int getIsLoggedIn() {
        return isLoggedIn;
    }

    public void setIsLoggedIn(int isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
    }
       
    public static List returnUsers() {
        return userList;
    }
    
    /**
     * Method to get logged in user's role
     * @return 
     */
    public static String getUserRole(){
        List<Admin> adminList = Admin.returnAdmin();       
        List<Learner> learnerList = Learner.returnLearners();
        String role = "";

        for (Learner learner : learnerList) {
            if (learner.getIsLoggedIn() == 1) {
                role = learner.getRole();
            }
        }
        for (Admin admin : adminList) {
            if (admin.getIsLoggedIn() == 1) {
                role = admin.getRole();
            }
        }
        
        return role;
    }
    
 
    
}
