
package hjss_package;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LearnerReport extends Report{
    
    /**
     * Export Learner Report
     */
    @Override
    public void exportReport(){
        
        HashMap<String, int[]> bookingCounter = new HashMap<>();
        
        List<Booking> bookingList = Booking.returnBookings();
        List<Learner> learnerList = Learner.returnLearners();

        Map<String, int[]> lessonCounter = new HashMap<>();

        // Iterate through bookings to count lessons for each learner
        for (Booking booking : bookingList) {
            int userId = booking.getUserId();
            String status = booking.getStatus();

            // Find the learner corresponding to the booking
            Learner learner = learnerList.stream().filter(l -> l.getUserId() == userId).findFirst().orElse(null);

            if (learner != null) {
                String learnerName = learner.getName();
                int[] counter = lessonCounter.getOrDefault(learnerName, new int[3]);

                if (status.equalsIgnoreCase(Booking.CANCELLED)) {
                    counter[0]++;
                } else if (status.equalsIgnoreCase(Booking.ATTENDED)) {
                    counter[1]++;
                } else if (status.equalsIgnoreCase(Booking.BOOKED)) {
                    counter[2]++;
                }

                lessonCounter.put(learnerName, counter);
            }
        }

        // Export report data to a CSV file using BufferedWriter
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("LearnerReport.csv"))) {
            // Write the header
            writer.write("Learner Name,Contact,Age,Gender,Grade Level,Cancelled Lessons, Attended Lessons, Booked Lessons");
            writer.newLine();

            // Write the data for each learner including contact and age
            for (Map.Entry<String, int[]> entry : lessonCounter.entrySet()) {
                String learnerName = entry.getKey();
                Learner learner = learnerList.stream().filter(l -> l.getName().equals(learnerName)).findFirst().orElse(null);

                if (learner != null) {
                    String contact = learner.getContact();
                    String gender = learner.getGender();
                    int age = learner.getAge();
                    int grade = learner.getGradeLevel();
                    int[] counter = entry.getValue();

                    writer.write(learnerName + ", " + contact + ", " + age +", " + gender +", " + grade + ", " + counter[0] + ", " + counter[1] + ", " + counter[2]);
                    writer.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
