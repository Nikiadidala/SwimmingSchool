
package hjss_package;

import java.util.ArrayList;


public class Admin extends User {
    
    private String address;
    
    public static ArrayList <Admin> adminList = new ArrayList<>();

    public Admin(String address, int userId, String name, String username, String password, String gender, int age, String contact, String role) {
        super(userId, name, username, password, gender, age, contact, role,0);
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public static ArrayList<Admin> returnAdmin() {
        Admin obj1 = new Admin("Eakring Rd, Mansfield, Nottinghamshire, United Kingdom",1,"Admin","admin","admin","Male",40,"01202 682247",COACH);
        adminList.add(obj1);
        return adminList;
    }
}
