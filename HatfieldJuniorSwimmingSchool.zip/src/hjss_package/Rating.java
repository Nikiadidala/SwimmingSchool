
package hjss_package;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.table.DefaultTableModel;


public class Rating {
    
    private String bookingNo;
    private int rating;
    private String review;
    private int givenBy;
    private int givenTo;

    public static String ATTENDING_BOOKING_NO = "";

    public static ArrayList <Rating> ratingList = new ArrayList<>();

    public Rating(String bookingNo,int rating, String review, int givenBy, int givenTo) {
        this.bookingNo = bookingNo;
        this.rating = rating;
        this.review = review;
        this.givenBy = givenBy;
        this.givenTo = givenTo;
    }

    public String getBookingNo() {
        return bookingNo;
    }

    public int getRating() {
        return rating;
    }

    public String getReview() {
        return review;
    }

    public int getGivenBy() {
        return givenBy;
    }

    public int getGivenTo() {
        return givenTo;
    }
    
    public static List returnRatings() {
        return ratingList;
    }
    
    /**
     * View Ratings
     * @param model
     * @param role 
     */
    public static void viewRatings(DefaultTableModel model, String role){
        List<Rating> ratingList = Rating.returnRatings();
        List<Booking> bookingList = Booking.returnBookings();
        List<Coach> coachList = Coach.returnCoach();
        List<Learner> learnerList = Learner.returnLearners();
        List<Lesson> lessonList = Lesson.returnLessons();
                
        for(int x=0; x<ratingList.size(); x++){
             
            String lessonName = "";
            String grade = "";
            String givenTo = "";
            String givenBy = "";
            String bookingNo = "";
        
            // If Learner
            if(role.equalsIgnoreCase(User.LEARNER)){
                
                if(ratingList.get(x).getGivenBy() == User.LOGGED_IN_USER){
        
                    //Get Lesson name
                    for(int i=0; i<bookingList.size(); i++){
                        if(bookingList.get(i).getBookingNo().equalsIgnoreCase(ratingList.get(x).getBookingNo())){

                             // get Lesson Deatils
                             for(int j=0; j<lessonList.size(); j++){

                                 if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                                     lessonName = lessonList.get(j).getName();
                                     grade = String.valueOf(lessonList.get(j).getGradeLevel());
                                 }
                             }
                        bookingNo = bookingList.get(i).getBookingNo();
                       }
                    }
                           
                    // Get Given By
                    for(int k=0; k<learnerList.size(); k++){
                        if(learnerList.get(k).getUserId() == ratingList.get(x).getGivenBy()){
                            givenBy = learnerList.get(k).getName();
                        }
                    }

                    // Get Given To
                    for(int k=0; k<coachList.size(); k++){
                        if(coachList.get(k).getUserId() == ratingList.get(x).getGivenTo()){
                            givenTo = coachList.get(k).getName();
                        }
                    }
                    
                    String[] arr = {bookingNo,lessonName,grade,String.valueOf(ratingList.get(x).getRating()),ratingList.get(x).getReview(),
                        givenTo,givenBy};
                    
                    model.addRow(arr);
                }
            // If Admin
            }else{
                //Get Lesson name
                for(int i=0; i<bookingList.size(); i++){
                    if(bookingList.get(i).getBookingNo().equalsIgnoreCase(ratingList.get(x).getBookingNo())){

                         // get Lesson Deatils
                         for(int j=0; j<lessonList.size(); j++){

                             if(lessonList.get(j).getLessonCode().equalsIgnoreCase(bookingList.get(i).getLessonCode())){
                                 lessonName = lessonList.get(j).getName();
                                 grade = String.valueOf(lessonList.get(j).getGradeLevel());
                             }
                         }
                   }
                   bookingNo = bookingList.get(i).getBookingNo();
                }

                // Get Given By
                for(int k=0; k<learnerList.size(); k++){
                    if(learnerList.get(k).getUserId() == ratingList.get(x).getGivenBy()){
                        givenBy = learnerList.get(k).getName();
                    }
                }

                // Get Given To
                for(int k=0; k<coachList.size(); k++){
                    if(coachList.get(k).getUserId() == ratingList.get(x).getGivenTo()){
                        givenTo = coachList.get(k).getName();
                    }
                }
                 
                String[] arr = {bookingNo,lessonName,grade,String.valueOf(ratingList.get(x).getRating()),ratingList.get(x).getReview(),
                    givenTo,givenBy};

                model.addRow(arr);
            }
        }
    }

    /**
     * Calculate Average Rating for each coach
     * @return 
     */
    public static HashMap<String, Double> calculateAverageRating() {
        HashMap<String, Double> averageRatings = new HashMap<>();
        HashMap<String, Integer> totalRatings = new HashMap<>();
        HashMap<String, Integer> totalNumOfRatingRecords = new HashMap<>();
        List<Coach> coachList = Coach.returnCoach();
        
        for (Rating rating : Rating.ratingList) {
            int coachId = rating.getGivenTo();
            int currentRating = rating.getRating();
            
            // Get the name of the coach based on their ID
            String givenTo = "";
            for (Coach coach : coachList) {
                if (coachId == coach.getUserId()) {
                    givenTo = coach.getName();
                    break; 
                }
            }
            
            totalRatings.put(givenTo, totalRatings.getOrDefault(givenTo, 0) + currentRating);
            totalNumOfRatingRecords.put(givenTo, totalNumOfRatingRecords.getOrDefault(givenTo, 0) + 1);
        }
        
        for (String coachName : totalRatings.keySet()) {
            int totalRating = totalRatings.get(coachName);
            int numberOfRatings = totalNumOfRatingRecords.get(coachName);
            
            if (numberOfRatings > 0) {
                double averageRatingCalculate = (double) totalRating / numberOfRatings;
                double roundedAverageRating = Math.round(averageRatingCalculate * 10.0) / 10.0; 
                averageRatings.put(coachName, roundedAverageRating);
            }
        }
        return averageRatings;
    }
}
